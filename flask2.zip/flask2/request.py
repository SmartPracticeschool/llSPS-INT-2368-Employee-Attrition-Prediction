import requests

url = 'http://localhost:5000/predict_api'
r = requests.post(url,json={'Attrition':2, 'BusinessTravel':9, 'Department':6, 'EducationField':5})
